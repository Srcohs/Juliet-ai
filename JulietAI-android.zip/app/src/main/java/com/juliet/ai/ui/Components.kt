package com.juliet.ai.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.Screen
import kotlin.random.Random

@Composable
fun SquareBtn(icon: ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(15.dp)
    Box(Modifier.size(46.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).clickable(onClick = onClick), Alignment.Center) {
        Icon(icon, desc, tint = p.text)
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)?) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        if (onBack != null) SquareBtn(Icons.Rounded.ArrowBack, "Back", onBack)
        Text(title, color = p.text, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 16.dp).padding(bottom = 120.dp)) {
        Header(title, onBack); content()
    }
}

@Composable
fun Sub(t: String) { Text(t, color = LocalPal.current.mu, fontSize = 16.sp, lineHeight = 22.sp, modifier = Modifier.padding(start = 4.dp, end = 4.dp, bottom = 16.dp)) }

@Composable
fun Sec(t: String) {
    Row(Modifier.padding(start = 6.dp, top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("✦", color = J.Red, fontSize = 14.sp); Spacer(Modifier.width(8.dp))
        Text(t, color = LocalPal.current.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
    }
}

@Composable
fun Group(content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(sh).background(p.card).border(1.dp, Brush.linearGradient(listOf(p.border, J.Red.copy(alpha = .4f), p.border)), sh).padding(6.dp), content = content)
}

@Composable
fun TileIcon(icon: String, size: Int = 44) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(13.dp)).background(J.Tile), Alignment.Center) { Text(icon, fontSize = (size * .45f).sp) }
}

@Composable
fun Chevron() { Icon(Icons.Rounded.ChevronRight, null, tint = LocalPal.current.mu) }

@Composable
fun Item(icon: String, title: String, sub: String? = null, trailing: @Composable () -> Unit = { Chevron() }, onClick: (() -> Unit)? = null) {
    val p = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TileIcon(icon)
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            if (!sub.isNullOrBlank()) Text(sub, color = p.mu, fontSize = 14.sp, lineHeight = 18.sp)
        }
        trailing()
    }
}

@Composable
fun ToggleItem(icon: String, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Item(icon, title, sub, trailing = {
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = J.Red, checkedThumbColor = Color.White, uncheckedBorderColor = Color.Transparent))
    }, onClick = { onChange(!checked) })
}

@Composable
fun Starfield(modifier: Modifier = Modifier) {
    val dots = remember { List(80) { val r = Random(it); Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
    androidx.compose.foundation.Canvas(modifier) {
        dots.forEach { (x, y, s) ->
            drawCircle(Color(0xFFFF9FB1).copy(alpha = .15f + s * .5f), (.6f + s * 1.6f) * density, Offset(x * size.width, y * size.height))
        }
    }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(36.dp)).background(J.Red).clickable(onClick = onClick).padding(vertical = 17.dp, horizontal = 30.dp), Alignment.Center) {
        Text(text, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, sel: Boolean, mod: Modifier, onClick: () -> Unit) {
    val c = if (sel) J.Red else LocalPal.current.mu
    Column(mod.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = c, modifier = Modifier.size(26.dp))
        Text(label, color = c, fontSize = 13.sp)
        Box(Modifier.padding(top = 2.dp).size(22.dp, 3.dp).clip(RoundedCornerShape(3.dp)).background(if (sel) J.Red else Color.Transparent))
    }
}

@Composable
fun BottomNav(cur: Screen, orb: Int, onGo: (Screen) -> Unit, onCore: () -> Unit) {
    val p = LocalPal.current
    val tab = if (cur == Screen.Home || cur == Screen.Chat || cur == Screen.History) cur else Screen.Settings
    val sh = RoundedCornerShape(38.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth().height(72.dp).clip(sh).background(p.nav).border(1.dp, p.border, sh), verticalAlignment = Alignment.CenterVertically) {
            NavItem("Home", Icons.Rounded.Home, tab == Screen.Home, Modifier.weight(1f)) { onGo(Screen.Home) }
            NavItem("Chat", Icons.Rounded.Chat, tab == Screen.Chat, Modifier.weight(1f)) { onGo(Screen.Chat) }
            Spacer(Modifier.width(88.dp))
            NavItem("History", Icons.Rounded.History, tab == Screen.History, Modifier.weight(1f)) { onGo(Screen.History) }
            NavItem("Settings", Icons.Rounded.Settings, tab == Screen.Settings, Modifier.weight(1f)) { onGo(Screen.Settings) }
        }
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-34).dp).size(72.dp).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(J.Gold, Color(0xFF8A5A1E), J.Gold, Color(0xFF8A5A1E), J.Gold)))
                .padding(4.dp).clickable(onClick = onCore)
        ) { JOrb(orb, Modifier.fillMaxSize(), animate = false, bare = true) }
    }
}
