package com.juliet.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val LogoBlue = Color(0xFF2F6BFF)
private val LogoViolet = Color(0xFFB445FF)

/** Animated splash: logo fades and scales in over a soft glow, a thin bar fills, then onDone(). Tap to skip. */
@Composable
fun SplashScreen(reduceMotion: Boolean, onDone: () -> Unit) {
    val alpha = remember { Animatable(if (reduceMotion) 1f else 0f) }
    val scale = remember { Animatable(if (reduceMotion) 1f else .86f) }
    val bar = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (reduceMotion) { delay(900); onDone(); return@LaunchedEffect }
        launch { alpha.animateTo(1f, tween(700)) }
        launch { scale.animateTo(1f, tween(1100, easing = FastOutSlowInEasing)) }
        launch { bar.animateTo(1f, tween(1700, easing = LinearEasing)) }
        delay(2100); onDone()
    }
    val t = rememberInfiniteTransition(label = "glow")
    val glow by t.animateFloat(.35f, .65f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "g")
    Box(
        Modifier.fillMaxSize().background(colorResource(R.color.splash_bg))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDone() },
        Alignment.Center
    ) {
        Box(
            Modifier.size(380.dp).graphicsLayer { this.alpha = alpha.value }.background(
                Brush.radialGradient(listOf(LogoBlue.copy(alpha = glow * .45f), LogoViolet.copy(alpha = glow * .22f), Color.Transparent))
            )
        )
        Image(
            painterResource(R.drawable.juliet_logo), "JULIET AI",
            Modifier.fillMaxWidth(.86f).aspectRatio(1f).graphicsLayer { this.alpha = alpha.value; scaleX = scale.value; scaleY = scale.value }
        )
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.width(160.dp).height(3.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = .12f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(bar.value).background(Brush.horizontalGradient(listOf(LogoBlue, LogoViolet))))
            }
            Text("Starting Juliet…", color = Color.White.copy(alpha = .6f), fontSize = 13.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 12.dp))
        }
    }
}
