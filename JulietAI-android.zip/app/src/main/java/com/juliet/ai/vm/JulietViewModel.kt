package com.juliet.ai.vm

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.juliet.ai.BuildConfig
import com.juliet.ai.data.*
import com.juliet.ai.net.GroqClient
import com.juliet.ai.phone.PhoneActions
import com.juliet.ai.voice.GeminiLive
import kotlinx.coroutines.launch

private const val GREETING = "I can chat, answer questions, and help you with your phone. Ask me anything!"
private val DEFAULTS = mapOf(
    "theme" to "System", "personality" to "Normal", "language" to "Auto", "style" to "Balanced",
    "voice" to "Kore", "model" to "gemini-2.5-flash-native-audio-preview-12-2025", "volume" to "80",
    "listen" to "1", "reduce" to "0", "orb" to "0", "name" to "Ahsan Raza"
)

class JulietViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val phone = PhoneActions(app)
    private val groq = GroqClient()
    val live = GeminiLive(phone)
    private var tts: TextToSpeech? = TextToSpeech(app) {}
    private var autoDone = false
    private var curId = System.currentTimeMillis()

    var stack by mutableStateOf(listOf(Screen.Home)); private set
    val screen: Screen get() = stack.last()
    val messages = mutableStateListOf<ChatMsg>()
    val convs = mutableStateListOf<Conv>()
    val st = mutableStateMapOf<String, String>()
    var busy by mutableStateOf(false); private set
    var draft by mutableStateOf("")
    var toast by mutableStateOf<String?>(null)
    var keyTick by mutableIntStateOf(0)
    var permTick by mutableIntStateOf(0)

    init {
        DEFAULTS.forEach { (k, v) -> st[k] = prefs.get(k, v) }
        convs.addAll(prefs.loadConvs())
        messages += ChatMsg("assistant", GREETING)
        viewModelScope.launch { live.error.collect { if (it != null) toast = it } }
    }

    // ---- settings ----
    fun s(k: String): String = st[k] ?: DEFAULTS[k] ?: ""
    fun set(k: String, v: String) { st[k] = v; prefs.put(k, v) }
    fun cycle(k: String, opts: List<String>) { set(k, opts[(opts.indexOf(s(k)) + 1) % opts.size]) }

    // ---- navigation ----
    private val tabs = setOf(Screen.Home, Screen.Chat, Screen.History, Screen.Settings)
    fun navigate(s: Screen) { stack = if (s in tabs) listOf(s) else if (s == screen) stack else stack + s }
    fun back() { stack = if (stack.size > 1) stack.dropLast(1) else listOf(Screen.Home) }

    // ---- keys ----
    fun geminiKey(): String = prefs.get("k_gemini").ifBlank { BuildConfig.DEFAULT_GEMINI_KEY }
    private fun groqKeys(): List<String> =
        prefs.get("k_groq").ifBlank { BuildConfig.DEFAULT_GROQ_KEYS }.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    fun geminiStatus(): String { keyTick; return status(prefs.get("k_gemini"), BuildConfig.DEFAULT_GEMINI_KEY) }
    fun groqStatus(): String { keyTick; return status(prefs.get("k_groq"), BuildConfig.DEFAULT_GROQ_KEYS) }
    private fun status(user: String, def: String) = when {
        user.isNotBlank() -> "✔ Your key saved"
        def.isNotBlank() -> "✔ Using Juliet's key"
        else -> "No key yet"
    }
    fun saveGemini(v: String) { prefs.put("k_gemini", v.trim()); keyTick++; toast = "Gemini key saved on this phone" }
    fun saveGroq(v: String) { prefs.put("k_groq", v.trim()); keyTick++; toast = "Groq keys saved on this phone" }

    // ---- typed chat ----
    fun sendText(raw: String) {
        val text = raw.trim(); if (text.isEmpty() || busy) return
        messages += ChatMsg("user", text); draft = ""
        phone.route(text)?.let { messages += ChatMsg("assistant", it); persist(); return }
        busy = true
        viewModelScope.launch {
            val r = groq.chat(groqKeys(), Persona.system(this@JulietViewModel), messages.map { GroqClient.Msg(it.role, it.text) })
            busy = false
            messages += ChatMsg("assistant", r.getOrElse { "Sorry, I couldn't reach Groq: ${it.message}" })
            persist()
        }
    }

    fun retry() {
        val i = messages.indexOfLast { it.role == "user" }; if (i < 0) return
        val t = messages[i].text
        while (messages.size > i) messages.removeAt(messages.size - 1)
        sendText(t)
    }

    fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "juliet") }

    private fun persist() {
        val first = messages.firstOrNull { it.role == "user" } ?: return
        val c = Conv(curId, first.text.take(40), messages.toList())
        val i = convs.indexOfFirst { it.id == curId }
        if (i >= 0) convs.removeAt(i)
        convs.add(0, c); prefs.saveConvs(convs)
    }

    fun newChat() {
        persist(); messages.clear(); messages += ChatMsg("assistant", GREETING)
        curId = System.currentTimeMillis(); toast = "New conversation"
    }
    fun openConv(c: Conv) { persist(); messages.clear(); messages.addAll(c.msgs); curId = c.id; navigate(Screen.Chat) }
    fun deleteConv(c: Conv) { convs.remove(c); prefs.saveConvs(convs) }

    // ---- voice ----
    fun startVoice() {
        val key = geminiKey()
        if (key.isBlank()) { toast = "Add a Gemini key in Settings > Connections"; return }
        live.onTranscript = { role, text -> viewModelScope.launch { messages += ChatMsg(role, text); persist() } }
        live.start(key, s("model"), s("voice"), Persona.system(this), (s("volume").toFloatOrNull() ?: 80f) / 100f)
    }
    fun stopVoice() = live.stop()
    fun autoStart(micOk: Boolean) {
        if (autoDone) return; autoDone = true
        if (s("listen") == "1" && micOk && geminiKey().isNotBlank()) startVoice()
    }

    fun clearAll() {
        live.stop(); prefs.clear(); st.clear(); DEFAULTS.forEach { (k, v) -> st[k] = v }
        convs.clear(); messages.clear(); messages += ChatMsg("assistant", GREETING)
        keyTick++; stack = listOf(Screen.Home); toast = "App data cleared"
    }

    override fun onCleared() { live.stop(); tts?.shutdown() }
}

object Persona {
    fun system(vm: JulietViewModel): String {
        val lang = if (vm.s("language") == "Auto") "Reply in the language the user speaks (Hindi, Urdu, English or a mix)."
        else "Reply in ${vm.s("language")}."
        val style = when (vm.s("style")) {
            "Short" -> "Keep replies to one or two sentences."
            "Detailed" -> "Give thorough, step by step answers."
            else -> "Keep replies clear and balanced in length."
        }
        return "You are Juliet, a warm voice-first personal AI assistant created by Ahsan Raza from Lahore, Pakistan. " +
            "Personality: ${vm.s("personality")}. $lang $style " +
            "You can control the phone with the tools open_app, call_contact and send_whatsapp. " +
            "Only say an action is done after the tool result says so. The user's name is ${vm.s("name")}."
    }
}
