package com.juliet.ai.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Typed chat through Groq's OpenAI-compatible API. Several keys take turns; a rate-limited key is skipped. */
class GroqClient {
    data class Msg(val role: String, val content: String)

    companion object { const val MODEL = "llama-3.3-70b-versatile" }   // change if Groq retires it

    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private var next = 0

    suspend fun chat(keys: List<String>, system: String, history: List<Msg>): Result<String> =
        withContext(Dispatchers.IO) {
            if (keys.isEmpty()) return@withContext Result.failure(IllegalStateException("Add a Groq key in Settings > Connections."))
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            history.takeLast(20).forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
            val body = JSONObject().put("model", MODEL).put("messages", msgs)
                .put("temperature", 0.7).put("max_tokens", 1024).toString()
                .toRequestBody("application/json".toMediaType())
            var last: Exception = IOException("Groq request failed")
            for (attempt in keys.indices) {
                val i = (next + attempt) % keys.size
                val req = Request.Builder().url("https://api.groq.com/openai/v1/chat/completions")
                    .header("Authorization", "Bearer ${keys[i]}").post(body).build()
                try {
                    http.newCall(req).execute().use { r ->
                        val txt = r.body?.string().orEmpty()
                        if (r.isSuccessful) {
                            next = (i + 1) % keys.size
                            val out = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                                .getJSONObject("message").getString("content")
                            return@withContext Result.success(out.trim())
                        }
                        last = IOException("Groq HTTP ${r.code}")
                        if (r.code !in listOf(401, 403, 429)) return@withContext Result.failure(last)
                    }
                } catch (e: Exception) { last = e }
            }
            Result.failure(last)
        }
}
