package com.juliet.ai.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Typed chat through Groq's OpenAI-compatible API.
 * - Several keys take turns; a rate-limited or rejected key is skipped.
 * - If a model has been retired (HTTP 404/400) the next model in MODELS is tried and remembered.
 * Groq retired llama-3.3-70b-versatile on 16 Aug 2026; check console.groq.com/docs/models for newer ones.
 */
class GroqClient {
    data class Msg(val role: String, val content: String)

    companion object {
        val MODELS = listOf("openai/gpt-oss-120b", "qwen/qwen3.6-27b", "openai/gpt-oss-20b")
    }

    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
    private var next = 0
    @Volatile private var good: String? = null

    private fun errText(body: String): String = try {
        JSONObject(body).getJSONObject("error").optString("message").take(160)
    } catch (e: Exception) { body.take(120) }

    private fun clean(s: String): String = s.replace(Regex("(?s)<think>.*?</think>"), "").trim()

    suspend fun chat(keys: List<String>, system: String, history: List<Msg>): Result<String> =
        withContext(Dispatchers.IO) {
            if (keys.isEmpty()) return@withContext Result.failure(IllegalStateException("Add a Groq key in Settings > Connections."))
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            history.takeLast(20).forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
            var last: Exception = IOException("Groq request failed")
            val order = listOfNotNull(good) + MODELS.filter { it != good }
            for (model in order) {
                var modelGone = false
                val body = JSONObject().put("model", model).put("messages", msgs)
                    .put("temperature", 0.7).put("max_completion_tokens", 1500)
                if (model.contains("gpt-oss")) body.put("reasoning_effort", "low")
                val payload = body.toString().toRequestBody("application/json".toMediaType())
                for (attempt in keys.indices) {
                    val i = (next + attempt) % keys.size
                    val req = Request.Builder().url("https://api.groq.com/openai/v1/chat/completions")
                        .header("Authorization", "Bearer ${keys[i]}").post(payload).build()
                    try {
                        http.newCall(req).execute().use { r ->
                            val txt = r.body?.string().orEmpty()
                            if (r.isSuccessful) {
                                next = (i + 1) % keys.size
                                good = model
                                val out = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                                    .getJSONObject("message").optString("content")
                                return@withContext Result.success(clean(out).ifBlank { "..." })
                            }
                            last = IOException("Groq HTTP ${r.code} (${errText(txt)})")
                            when (r.code) {
                                401, 403, 429 -> {}              // try the next key
                                400, 404 -> modelGone = true     // model retired or not allowed: next model
                                else -> return@withContext Result.failure(last)
                            }
                        }
                    } catch (e: Exception) { last = e }
                    if (modelGone) break
                }
            }
            Result.failure(last)
        }
}
