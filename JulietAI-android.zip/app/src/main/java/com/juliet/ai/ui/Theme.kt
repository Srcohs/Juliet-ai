package com.juliet.ai.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object J {
    val Red = Color(0xFFFF1E46)
    val Crim = Color(0xFFFF3366)
    val Dark = Color(0xFF990B24)
    val Ok = Color(0xFF2FF0BB)
    val Gold = Color(0xFFE8B56A)
    val Tile = Brush.linearGradient(listOf(Color(0xFF8F0A22), Color(0xFFFF1E46)))
}

data class Pal(val bg: Color, val card: Color, val card2: Color, val border: Color, val text: Color, val mu: Color, val nav: Color)

val DarkPal = Pal(Color(0xFF06050A), Color(0xFF13090F), Color(0xFF1B0C14), Color(0xFF4A1626), Color.White, Color(0xFFB8A5AA), Color(0xFF1D0B13))
val LightPal = Pal(Color(0xFFFFF3F5), Color.White, Color(0xFFFFF0F3), Color(0xFFF2BCC8), Color(0xFF2A0A12), Color(0xFF7D5A63), Color.White)
val LocalPal = staticCompositionLocalOf { DarkPal }

@Composable
fun JulietTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPal else LightPal
    val cs = if (dark) darkColorScheme(primary = J.Red, background = p.bg, surface = p.card, onBackground = p.text, onSurface = p.text)
    else lightColorScheme(primary = J.Red, background = p.bg, surface = p.card, onBackground = p.text, onSurface = p.text)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = cs, content = content) }
}
