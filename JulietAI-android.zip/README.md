# JULIET AI - Android (Kotlin + Jetpack Compose)

Voice-first assistant by Ahsan Raza.
- Voice: Gemini Live API (WebSocket), phone tools: open app, call, WhatsApp.
- Typed chat: Groq, several keys take turns on rate limits.
- Keys, settings and chats are stored encrypted on the phone.
- Splash with your logo, orb styles, history, permissions.

## Get the APK from GitHub (no Android Studio needed)
1. Create a free account at github.com, then New repository, name it JulietAI (Private is fine), Create.
2. On a computer unzip JulietAI-android.zip. In the folder run:
       git init
       git add .
       git commit -m "Juliet AI"
       git branch -M main
       git remote add origin https://github.com/YOUR_NAME/JulietAI.git
       git push -u origin main
   (No git? Use the repo page: Add file > Upload files, drag everything. Hidden folders such as .github
   are often skipped, so afterwards check that .github/workflows/android.yml exists; if not, use
   Add file > Create new file, type .github/workflows/android.yml and paste the file's text.)
3. Open the repo's Actions tab. "Build Android APK" starts by itself (about 5 to 8 minutes).
4. When it is green, open the run, scroll to Artifacts and download JulietAI-debug-apk. Unzip it to get app-debug.apk.
5. Send the APK to your phone and install it (allow "Install unknown apps" for your file manager or browser).
6. Open Juliet AI > Settings > Connections, paste your Gemini key (aistudio.google.com/apikey) and Groq key(s) (console.groq.com/keys).
7. Optional public download link: tag a release. git tag v1.4.0 && git push origin v1.4.0
   The APK then appears under the repo's Releases.

If the build turns red, open the failed step, copy the error text and send it to Claude to fix.

## Run locally instead
Open the folder in Android Studio (Koala or newer), let Gradle sync, run on a real phone.

## Before you share it
- Model names change: voice models in SettingsScreens.kt (VoiceScreen), Groq model in GroqClient.MODEL.
- A debug APK is fine for your own phones. For Play Store you need a signed release build.
- Built-in keys through local.properties (juliet.gemini, juliet.groq) can be extracted from an APK. Keep them out of public builds.
- Voice pauses if another app opens (Android blocks background microphone).
